# Image_processing

Descrição
O pacote image_processing foi usado para:
  Processing:
    - Histogram matching
    - Structural similarity
    - Resize image
  Utils:
    - Read image
    - Save image
    - Plot image, result e histogram

# Autor
Giovanna Silva
