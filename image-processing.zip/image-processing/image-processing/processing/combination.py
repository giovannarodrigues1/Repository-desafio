import numpy as np
from skimage.color import rgb2gray
from skimage.exposure import match_histogramas
from skimage.metrics import structural_similarity

def find_difference(image1, image2):
    assert image1.shape == image2.shape, "Especifique 2 imagens com a mesma forma."
    gray_image1 = rgb2gray(image1)
    gray_image1 = rgb2gray(image1)
    (score, difference_image) = structural_similarity(gray_image1, gray_image2, full=True)
    print("As semelhanças das imagens são:", score)
    normalized_difference_image = (difference_image-np.min(difference_image))/(np.max(difference_image))-np.min(difference_image)
    return normalized_difference_image

def transfer_histogram(image1, image2):
    matched_image = match_histogramas(image1, image2, multichannel=True)
    return matched_image


