from setuptools import setup, find_packages

with open("README.md", "r") as f:
    page_description = f.read()

with open("requirements.txt") as f:
    requirements = f.read().splitlines()

setup(
    name="image-processing",
    version="0.0.1",
    author="Giovanna Silva",
    author_email="gihrodrigues146@gmail.com",
    description="Este é meu primeiro projeto trabalhando com pacote de imagens em Python.",
    long_description=page_description,
    long_description_content_type="text/markdown",
    url="https://github.com/giovannarodrigues1/Repository-desafio.git"
    packages=find_packages(),
    install_requires=requirements,
    python_requires='>=3.8',
)